import os

def getPath ():
	return os.path.dirname (os.path.realpath (__file__))