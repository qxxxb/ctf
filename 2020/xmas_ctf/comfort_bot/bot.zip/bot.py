import discord, asyncio
import engine, os

def getPath ():
	return os.path.dirname (os.path.realpath (__file__))

prefix = "comf"
client = discord.Client()

@client.event
async def on_message (message):
	if (message.author == client.user): return
	
	authorID = message.author.id

	if (isinstance(message.channel, discord.DMChannel)):
		guildID = 0
	else:
		authorID = 0
		guildID = message.channel.guild.id

	response = ""
	spell = False

	if (message.content.lower ().startswith (prefix.lower ())):
		message.content = message.content [len (prefix):].strip ()
		response = await engine.process (message.content, authorID, guildID)

	elif (message.content.startswith ("!")):
		spell = True
		response = await engine.getCleverResponse (authorID, message.content[1:])

	elif (message.content.startswith ("$")):
		spell = True
		response = message.content[1:]

	if (len (response) > 0):
		try:
			if (spell):
				try:
					voiceChannel = client.get_channel (message.author.voice.channel.id)
				except Exception as e:
					voiceChannel = None

				if (voiceChannel != None):
					responseCode = await engine.connect (guildID, voiceChannel)

					if (guildID in engine.voiceClients and engine.voiceClients[guildID].is_connected ()):
						voiceFile = getPath () + "/audioOutput/{}.wav".format (guildID)
						engine.generateWAV (response, authorID, voiceFile)

						voiceClient = engine.voiceClients[guildID]
						voiceClient.stop ()
						audioSource = discord.FFmpegPCMAudio (voiceFile)
						voiceClient.play (audioSource)

		except discord.errors.ClientException as e:
			await message.channel.send (response)
			print ("Rebooting from Discord error")
			print (e)
			exit ()
			
		await message.channel.send (response)

@client.event
async def on_ready ():
	print (client.user.name + " booted up.")
	await client.change_presence (activity = discord.Game (name = "HELLO. I AM COMFORT BOT. \"COMF HELP\""))

try:
	token = open (getPath () + "/token", "r").read ().strip ()
except:
	print ("Please create a 'token' file with your discord bot token in the same directory as the bot script.")
	exit (1)

if (not os.path.isdir (getPath () + "/audioOutput")):
	os.mkdir (getPath () + "/audioOutput")

engine.createCleverDriver ()
engine.initializeAudioEngines ()
client.run (token)
