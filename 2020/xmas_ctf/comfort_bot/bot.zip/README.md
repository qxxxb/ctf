# Pinguinul Stie Tot

The "official" repo for HTsP's Pinguinul bot. He gives us CTF information and some good banter.

## Notes:

- For the Tacotron voice engine, you'll need tensorflow 1.15. 2.0 doesn't work. Also, I copied the entire tacotron2 repo in there so you wouldn't need to bother setting all that thing up. Apparently the MLP tacotron engine requires a specific commit (?) Not sure what that thing is all about, and I'm too lazy to have a look at it. What's currently in here works, I guess.