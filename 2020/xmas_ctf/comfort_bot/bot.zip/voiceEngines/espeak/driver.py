import subprocess, os

def getPath ():
	return os.path.dirname (os.path.realpath (__file__))

authorData = {}

defaultVoiceProfile = """name pinguin
language en
pitch {} {}
roughness 6
voicing 100
speed {}
"""

def initialize ():
	pass
	
def generateWAV (message, authorID, outputFile):
	voiceData = {"pitch": 150, "speed": 120}

	if (authorID in authorData):
		if ("pitch" in authorData[authorID]):
			voiceData["pitch"] = authorData[authorID]["pitch"]
		if ("speed" in authorData[authorID]):
			voiceData["speed"] = authorData[authorID]["speed"]

	voiceProfile = getPath () + "/espeak-data/voices/pinguin"
	#o = open (voiceProfile, "w")
	#o.write (defaultVoiceProfile.format (voiceData["pitch"], voiceData["pitch"] + 100, voiceData["speed"]))
	#o.close ()

	subprocess.call (['espeak', '--path=' + getPath (), '-vpinguin', '-w', outputFile, message])

def updateAuthorData (authorID, message):
	message = message.split (",")

	if (authorID not in authorData):
		authorData[authorID] = {}

	for token in message:
		try:
			token = token.split ("=")
			authorData[authorID][token[0]] = int (token[1])
		except:
			return "Setari de voce invalide.\nExemplu: `voce pitch=120,speed=10`"

	return "Setari de voce salvate cu succes."