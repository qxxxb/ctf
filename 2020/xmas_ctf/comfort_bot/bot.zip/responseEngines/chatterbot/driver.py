import os
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

def getPath ():
	return os.path.dirname (os.path.realpath (__file__))

def trainAI ():
	conv = eval (open (getPath () + "corpus", "r").read ())

	for channel in conv:
		for date in conv[channel]:
			trainer.train (conv[channel][date])

def createCleverDriver ():
	global chatbot

	chatbot = ChatBot ('Pinguinul', 
						storage_adapter='chatterbot.storage.SQLStorageAdapter',
						database_uri='sqlite:///' + getPath () + "/db.sqlite3"
						)
	trainer = ListTrainer (chatbot)

def getCleverResponse (txt):
	global chatbot

	if (len (txt) == 0):
		return ""
	else:
		return chatbot.get_response (txt).text