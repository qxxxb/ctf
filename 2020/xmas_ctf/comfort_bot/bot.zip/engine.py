import requests, random, datetime
import discord, subprocess, textData
import responseEngines.cleverbot.driver as cleverDriver

# Unsupported on my HW:
# import voiceEngines.tacotron.drivergpu as voiceEngineTacotron
import voiceEngines.espeak.driver as voiceEngineEspeak

def getPath ():
	return os.path.dirname (os.path.realpath (__file__))

version = "1.9.2"
userList = []
voiceClients = {}
voiceEngines = {}

codeOK = 0
codeInaccessible = 1
codeAlreadyThere = 2

months = {'Jan.':'Ianuarie', 'Feb.':'Februarie', 'March':'Martie', 'April':'Aprilie', 'May':'Mai', 'June':'Iunie', 'July':'Iulie', 'Aug.':'August', 'Sept.':'Septembrie', 'Oct.':'Octombrie', 'Nov.':'Noiembrie', 'Dec.':'Decembrie'}
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0'}

async def process (message, authorID, guildID):
	msgLower = message.lower ()
	if (msgLower.startswith ("help")):
		outMsg = ":grapes: Comfort Bot **{}**\n".format (version)

		for msg in textData.helpMsgs:
			outMsg += "\t**- {}:** `{}`\n".format (msg, textData.helpMsgs[msg])

	elif (msgLower.startswith ("ping")):
		outMsg = random.choice (textData.pong)

	elif (msgLower.startswith ("bye")):
		responseCode = await disconnect (guildID)

		if (responseCode == codeInaccessible):
			outMsg = random.choice (textData.leaveVoiceNotOnChannel)
		else:
			outMsg = random.choice (textData.leaveVoice)

	elif (msgLower.startswith ("voicesettings")):
		message = " ".join (message.split ()[1:])
		outMsg = updateAuthorData (authorID, message)

	elif (msgLower.startswith ("restart")):
		# Yeah, creator only stuff, when I need to reset boombox and I'm away
		if (authorID == 350042456256937984):
			print ("Restarting Comfort Bot")
			exit (0)
		else:
			await ch.send ("Unauthorized.")

	elif ("ctf" in msgLower):
		if ("now" in msgLower):
			outMsg = getActiveCTFs ()
		else:
			outMsg = getCTFs (parseCTFCount (msgLower))

	elif (len (message) == 0):
		outMsg = random.choice (textData.noCmd)

	else:
		outMsg = await getCleverResponse (authorID, message)
	
	return outMsg

def createCleverDriver ():
	cleverDriver.createCleverDriver ()

async def getCleverResponse (authorID, message):
	if (authorID == 0):
		return random.choice(["Oh, I quite certainly agree.", "There, there, it's alright.", "Oh!", "Fascinating!", "Exquisite reply!", "Running program: COMFORT.", "Understandable.", "Hmm.", "I see.", "Well, if you really think that...", "What are you doing?", "What are you up to?", "What's that?", "[Nodding]", "[Nodding and stroking chin saying mhmm]"])
	else:
		return await parseUsers (cleverDriver.getCleverResponse (authorID, message))

def initializeAudioEngines ():
	#voiceEngineTacotron.initialize ()
	voiceEngineEspeak.initialize ()

def generateWAV (message, authorID, outputFile):
	if (authorID not in voiceEngines): voiceEngines[authorID] = voiceEngineEspeak
	voiceEngines[authorID].generateWAV (message, authorID, outputFile)

def updateAuthorData (authorID, message):
	if (authorID not in voiceEngines): voiceEngines[authorID] = voiceEngineEspeak
	return voiceEngines[authorID].updateAuthorData (authorID, message)

async def connect (guildID, voiceChannel):
	global voiceClients
			
	if (voiceChannel == None):
		return codeInaccessible

	if (guildID in voiceClients and not voiceClients[guildID].is_connected ()):
		await voiceClients[guildID].disconnect ()
		voiceClients.pop (guildID, None)
	
	if (guildID in voiceClients and voiceClients[guildID].channel.id != voiceChannel.id):
		await voiceClients[guildID].disconnect ()
		voiceClients.pop (guildID, None)

	if (guildID not in voiceClients):
		voiceClient = await voiceChannel.connect ()
		voiceClients[guildID] = voiceClient
		return codeOK
	else:
		return codeAlreadyThere

async def disconnect (guildID):
	global voiceClients

	if (guildID not in voiceClients):
		return codeInaccessible
	else:
		await voiceClients[guildID].disconnect ()
		voiceClients.pop (guildID, None)

		return codeOK

def parseUsers (text):
	global userList

	try:
		if (len (userList) == 0):
			fp = open (utils.getPath () + "/users", "r")
			userList = fp.read ().split ("\n")
			fp.close ()

		for user in userList:
			user = user.split (" ")
			text = text.replace (user[0], user[1])
	except:
		pass

	return text

def parseCTFCount (message):
	cnt = [int (s) for s in message if s.isdigit ()]

	if (len (cnt) == 0):
		if (" un " in message.lower ()):
			cnt = 1
		elif (" doua " in message.lower ()):
			cnt = 2
		else:
			cnt = 3
	else:
		cnt = cnt[0]

		if (cnt > 8):
			cnt = 8
		elif (cnt < 1):
			cnt = 1

	return cnt

def getActiveCTFs ():
	r = requests.get ("https://ctftime.org/", headers = headers).text.replace ('&#39;', "'")

	if (r.find ("Now running") != -1):
		outMsg = random.choice (textData.ctfuriacum) + '\n\n'
		r = r[r.find ("Now running"):]
		r = r[:r.find ("</table>")]

		number = 1

		while (r.find ("<a href=") != -1):
			first = r[r.find ("<a href="):]
			link = first[9:first.find("\" style")]

			r = r[r.find ("#000000") + 1:]
			r = r[r.find ("#000000") + 9:]
			name = r[:r.find ("</a>")]

			r = r[r.find ("<td>&nbsp;") + 11:]
			timeLeft = r[:r.find (" more")]

			outMsg += textData.ctfNowTemplate.format (**locals ())
			number += 1
	else:
		outMsg = random.choice (textData.noctf)

	return outMsg

def getCTFs (cnt):
	outMsg = random.choice (textData.ctfuri) + '\n'
	r = requests.get ("https://ctftime.org/event/list/?year={}&online=-1&format=0&restrictions=-1&upcoming=true".format (datetime.datetime.now ().year), headers = headers).text.replace('&#39;', "'")
	
	for month in months:
		r = r.replace (month, months[month])

	r = r[r.find ('<table class="table table-striped">'):]
	r = r[:r.find ('</table>')]
	r = r.split ('<tr>')[2:]
	
	number = 1

	for entry in r:
		entry = entry.split('<td>')
		print (entry)

		link = entry[1]
		name = link[link.find('">') + 2:link.find('</a>')]
		link = link[link.find('"') + 1:link.find('">')]

		date = entry[2][:-5]
		dateStart = date[:date.find ("&mdash;")].strip ()
		dateEnd = date[date.find ("&mdash;") + 7:].strip ()

		CTFType = entry[3][:-5]
		location = entry[4][:-5].strip()
		if (len (location) == 0): location = "?"
		weight = entry[5][:-5]
		notes = entry[6][:-5].strip()[3:-4]
		teams = entry[7][:-5].strip()
		teams = teams[teams.find('<b>') + 3:teams.find('</b>')]
		
		outMsg += textData.ctfListTemplate.format (**locals ())

		if (number == cnt or number >= len (r)):
			break

		number += 1

	return outMsg