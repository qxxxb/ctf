helpMsgs = {
	"help": "Show this message",
	"ping": "See if the comfort bot is online",
	"bye": "Kick comfort bot from the voice channel",
	"voicesettings setting1=sth,setting2=sthelse": "Change voice settings",
	"show me X ctfs": "Ask the comfort bot what the next X ctfs are!",
	"show me X ctfs that are happening now": "Ask the comfort bot what CTFs are happening right now.",	
}

cmdUse = "Use: {}"
updateAuthorData = "{} changed to {}"

unknownError = ["Unknown error."]

noCmd = ["Hi", "What's up?", "Yes!", "How are you doing?", "Tell me what your problems are.", "I'm listening.", "Hello fellow hardworking gnome!"]
pong = ["Pong.", "Check, check 1 2 3\nHmm, seems looks like it should work.", "I'm here."]

joinVoice = ["Reporting for duty!", "I'm coming towards you.", "I'm arriving!", "Just a sec!"]
joinVoiceAlreadyThere = ["I'm already on this channel."]
joinVoiceInaccessible = ["I somehow cannot join the voice channel!"]

leaveVoice = ["Goodbye!", "I'm glad I could help!"]
leaveVoiceNotOnChannel = ["I'm not on any voice channel."]

ctfuri = ["Here's what's in my calendar:", "In a jiffy!", "Here you go!", "Here comes a list of future CTFs!"]
ctfuriacum = ["These CTFs are happening right now!", "Here are what CTFs are happening now, according to CTFTime:"]
noctf = ["There aren't any CTFs right now."]

ctfListTemplate = """{number}. **{name}** (<https://ctftime.org{link}>)
From _{dateStart}_ til _{dateEnd}_
Weight: **{weight}** | **{teams}** participating teams
Type: **{CTFType}** | Location: **{location}**
\n"""

ctfNowTemplate = """{number}. **{name}** (<https://ctftime.org{link}>)
**{timeLeft}** left.
\n"""