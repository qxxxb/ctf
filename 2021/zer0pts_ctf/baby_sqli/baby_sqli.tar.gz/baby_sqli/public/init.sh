#!/bin/sh
cd /home/app && python3 server.py
